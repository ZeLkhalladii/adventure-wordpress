<!DOCTYPE html>
<html lang="fr">
	

<!-- Mirrored from www.mediaweb.ca/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 20 Mar 2019 15:13:26 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<!-- META -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta content="Mediaweb.ca" name="copyright" /><meta content="Mediaweb.ca" name="publisher" /><meta content="General" name="rating" /><meta content="Global" name="distribution" /><meta content="Completed" name="document-class" /><meta content="General" name="document-rating" /><meta content="Quebec, Canada, North America" name="document-classification" /><meta content="Public" name="cache-control" /><meta content="Public" name="document-right" /><meta content="index, follow" name="robots" /><meta content="30 days" name="revisit-after" /><meta content="20160126" name="date-creation" /><meta content="http://www.mediaweb.ca" name="identifier-url" /><meta content="Mediaweb leader dans la création de site conception web pour le grand Montréal depuis 1996." name="description" /><meta content="création web, conception site web, création sites internet, sites internet, design web, seo, search engine optimization, référencement web, web, site web, création conception" name="keywords" /><meta content=" conception site web " name="abstract" /><meta content=" création site web " name="owner" /><meta content="référencement SEO" name="author" />	<meta property="og:title" content=" Création site web Montréal " />
	<meta property="og:site_name" content="Mediaweb" />
	<meta property="og:url" content="index.html" />
	<meta property="og:image" content="images/fusee.png" />
	<meta property="og:description" content="Mediaweb leader dans la création de site conception web pour le grand Montréal depuis 1996." />
	
		
		
		
	<title> Création site web Montréal | Mediaweb</title>

	<!-- STYLESHEETS -->
			<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,200,200italic,300,300italic,400italic,600,600italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
		
	<link href="favicon.png" type="image/png" rel="icon">
	
	<link href="style.css" rel="stylesheet">
</head>	<link href="css/addons/magnific-popup/magnific-popup.css" rel="stylesheet">

	<body class="scrollSystem" data-browser="">
		<!-- RÉFÉRENCEMENT -->

		<h1 class="referencement">
			Création site web Montréal 		</h1>

		<a href="#mediaweb" class="hidden-mobile">
			<img src="images/svg/mw-icon.svg" class="svg mwlogo">
		</a>

    <!-- Mobile Menu Toggle -->
    <i class="fa fa-bars mobile-menu-toggle visible-mobile"></i>

		
<!-- Left Navbar -->
<nav class="nav-fixed" data-disabledfirstsection="1">
	<ul>
		<li>
			<div class="item">
				<a href="#solution-web" data-section-index="2">
					<span class="text">Solutions web</span>
					<img src="images/svg/adaptez-vous.svg" class="svg icon" alt=""
					data-appearduration="1" data-appeardelay="0.30">
				</a>
			</div>
		</li>
		<li>
			<div class="item">
				<a href="#conception-web" data-section-index="3">
					<span class="text">Conception web</span>
					<img src="images/svg/remues-nos-meninges.svg" class="svg icon" alt=""
					data-appearduration="1" data-appeardelay="0.40">
				</a>
			</div>
		</li>
		<li>
			<div class="item">
				<a href="#seo" data-section-index="4">
					<span class="text">SEO</span>
					<img src="images/svg/soyez-les-premiers.svg" class="svg icon" alt=""
					data-appearduration="1" data-appeardelay="0.50">
				</a>
			</div>
		</li>
		<li>
			<div class="item">
				<a href="#social" data-section-index="5">
					<span class="text">Social</span>
					<img src="images/svg/rejoignez-votre-clientele.svg" class="svg icon" alt=""
					data-appearduration="1" data-appeardelay="0.60">
				</a>
			</div>
		</li>
		<li>
			<div class="item">
				<a href="#realisations" data-section-index="6">
					<span class="text">Réalisations</span>
					<img src="images/svg/demarquez-vous.svg" class="svg icon" alt=""
					data-appearduration="1" data-appeardelay="0.70">
				</a>
			</div>
		</li>
	</ul>
</nav>

    
<!-- MODULE-MENU-MOBILE -->
<div class="module-menu-mobile">
  <div class="wrapper">
    <ul>
      <!-- Logo -->
      <li>
        <a href="index-2.html#mediaweb">
    			<img src="images/svg/mw-icon.svg" class="svg logo">
    		</a>
      </li>

      <!-- #solution-web -->
      <li>
        <a href="#solution-web">
          Solutions Web
        </a>
      </li>

      <!-- #conception-web -->
      <li>
        <a href="#conception-web">
          Conception Web
        </a>
      </li>

      <!-- #seo -->
      <li>
        <a href="#seo">
          SEO
        </a>
      </li>

      <!-- #social -->
      <li>
        <a href="#social">
          Social
        </a>
      </li>

      <!-- #realisations -->
      <li>
        <a href="#realisations">
          Réalisations
        </a>
      </li>

      <!-- Contact -->
      <li>
        <a href="creation-web-montreal.html">
          Contact
        </a>
      </li>

      <!-- Share -->
      <li>
        <a target="_blank" href="https://www.facebook.com/mediaweb.ca"><i class="fa fa-facebook"></i></a>
      </li>

    </ul>
  </div>
</div>

    
<!-- Footer Menu Bar -->
<div class="footer-menu-bar hidden-mobile">
  <div class="toggle-button">
    <i class="fa fa-bars"></i>
  </div>
  <div class="container">
    <div class="col-xs-1 col-md-1 no-padding">
      <a href="#mediaweb" data-section-index="1" class="full">
        <img src="images/svg/mw-icon.svg" class="svg">
      </a>
    </div>
    <div class="col-xs-2 col-md-1 no-padding">
      <a href="index-2.html" class="full">Accueil</a>
    </div>
    <div class="col-xs-2 col-md-1 no-padding">
      <a href="creation-web-montreal.html">Contact</a>
    </div>
    <div class="col-xs-5 col-xs-push-2 col-md-push-5 no-padding">
      <span>1 (866) 334-2932 <b>&nbsp;|&nbsp;</b> (514) 990-7622</span>
      <a target="_blank" href="https://www.facebook.com/mediaweb.ca"><i class="fa fa-facebook"></i></a>
    </div>
  </div>
</div>
<!-- End Footer Menu Bar -->

    <style>
      .dee-popup {
        top: 20px;
        left: 50%;
        z-index: 1000;
        display: table;
        position: fixed;
        -webkit-transform: translateX(-50%);
        -moz-transform: translateX(-50%);
        transform: translateX(-50%);
      }
      .dee-popup img {
        position: relative;
      }
    </style>

		<!-- Section Home -->
		<section id="mediaweb" class="full-section full-section-mobile">
			<div class="background-light"></div>
			<div class="total-center total-center-mobile">
				<img src="images/svg/logo-slogan.svg" width="620" height="211" class="svg logo appear img-responsive" data-appearduration="0.75" alt="Création site web Montréal" title="Création site web Montréal">
        <a href="#solution-web" class="down-anchor visible-mobile">
          <i class="fa fa-angle-down"></i>
        </a>
        <div class="link-icons hidden-mobile">
					<!-- Icon : solution-web -->
					<a href="#solution-web" data-title="Solutions web" data-section-index="2">
						<img src="images/svg/adaptez-vous.svg" class="svg icon appear" alt="Création site web" title="Création site web"
						data-appearduration="1.25" data-appeardelay="0.50">
					</a>
					<br class="visible-xxs">
					<!-- Icon : conception-web -->
					<a href="#conception-web" data-title="Conception web" data-section-index="3">
						<img src="images/svg/remues-nos-meninges.svg" class="svg icon appear" alt="site web" title="site web"
						data-appearduration="1.25" data-appeardelay="0.60">
					</a>
					<!-- Icon : seo -->
					<a href="#seo" data-title="SEO" data-section-index="4">
						<img src="images/svg/soyez-les-premiers.svg" class="svg icon appear" alt="conception site web " title="Conception site web"
						data-appearduration="1.25" data-appeardelay="0.80">
					</a>
					<!-- Icon : social -->
					<a href="#social" data-title="Social" data-section-index="5">
						<img src="images/svg/rejoignez-votre-clientele.svg" class="svg icon appear" alt="site internet" title="site internet"
						data-appearduration="1.25" data-appeardelay="0.70">
					</a>
					<!-- Icon : realisations -->
					<a href="#realisations" data-title="Réalisations" data-section-index="6">
						<img src="images/svg/demarquez-vous.svg" class="svg icon appear" alt="réalisation web" title="réalisations"
						data-appearduration="1.25" data-appeardelay="0.90">
					</a>
					<!-- Caption -->
					<p class="icons-caption appear"></p>
				</div>
			</div>
			<img src="images/svg/curve.svg" style="width:100%;" class="svg curve dark-blue" alt="Création site web Montréal" title="Création site web Montréal">
		</section>

		<!-- Section Solution Web -->
		<section id="solution-web" class="full-section">
			<div class="background-stars parallax skewMouseBG"></div>
			<div class="total-center">
				<div class="container-fluid">
					<div class="col-xs-12">
						<h3 class="section-title appear">ADAPTEZ-VOUS</h3>
						<p class="appear">
							<b>Mediaweb</b> demeure &agrave; l'affut des tendances en matière de <b>création</b> et de <b>conception de sites internet</b>. C'est pourquoi nous sommes en mesure de vous suggérer les meilleures <b>solutions web</b> pour vous propulser dans la stratosphère du web.
						</p>
					</div>
					<div class="col-xs-12 col-md-4">
						<ul class="appear">
							<li><span>[</span> Responsive</li>
							<li><span>[</span> Flat design</li>
							<li><span>[</span> One-pager</li>
							<li><span>[</span> Mobile First</li>
							<li><span>[</span> Contenu autogérable</li>
						</ul>
					</div>
					<div class="col-xs-12 col-md-8 hidden-xs hidden-sm">
						<div class="appear animated-screen" style="width:1032px; height:655px;">
							<img src="images/solution-web-spaceship.png" width="99" height="223" class="spaceship" alt="site web Montréal" title="site web Montréal">
							<img src="images/solution-web-screens.png" width="1032" height="655" class="img-responsive" alt="Création conception" title="Création conception">
							<img src="images/solution-web-screens-layer-cloud.png" width="1032" height="655" class="layer-cloud" alt="design" title="design">
							<img src="images/solution-web-screens-layer-trails.png" width="1032" height="655" class="layer-trails" alt="publicité web" title="publicité internet">
						</div>
					</div>
					<div class="col-xs-12">
						<a href="design-web-solutions.html" class="section-button appear">
							<img src="images/button-arrow.png" width="50" height="25" class="" alt="design" title="design site web Montréal"> EN SAVOIR PLUS
						</a>
					</div>
				</div>
			</div>
			<img src="images/svg/curve.svg" style="width:100%;" class="svg curve red" alt="referencement" title="SEO">
		</section>

		<!-- Section Conception Web -->
		<section id="conception-web" class="full-section">
			<div class="total-center">
				<div class="container-fluid">
					<div class="col-xs-12">
						<h3 class="section-title appear">ON REMUE NOS MÉNINGES !</h3>
					</div>
					<div class="col-xs-12">
						<p class="appear">
							<b>Rédaction, design, marketing :</b> autant d'aspects maîtrisés par notre équipe de savants du web!
							Découvrez comment <b>Mediaweb</b> peut vous mettre en valeur grâce &agrave; ses différents <b>services de conception web</b>.
						</p>
					</div>
					<div class="col-xs-12">
						<div class="animated-brain">
							<img src="images/svg/brain.svg" class="svg brain appear" />
							<img src="images/svg/brain-icons-top-left.svg" class="svg brain-parts-1 brain appear" data-appeardelay="0.5" />
							<img src="images/svg/brain-icons-top-right.svg" class="svg brain-parts-2 brain appear" data-appeardelay="1" />
							<img src="images/svg/brain-icons-bottom-left.svg" class="svg brain-parts-3 brain appear" data-appeardelay="1.5" />
							<img src="images/svg/brain-icons-bottom-right.svg" class="svg brain-parts-4 brain appear" data-appeardelay="2" />
						</div>
						<a href="conception-sites-web.html" class="section-button appear">
							<img src="images/button-arrow.png" width="50" height="25" class="" alt="Conception site web" title="conception"> EN SAVOIR PLUS
						</a>
					</div>
				</div>
			</div>
			<img src="images/svg/curve.svg" style="width:100%;" class="svg curve gray" alt="Montreal" title="Montréal">
		</section>

		<!-- Section SEO -->
		<section id="seo" class="full-section">
			<div class="background-chalk parallax"></div>
			<div class="total-center">
				<div class="col-xs-12">
					<h3 class="section-title appear">SOYEZ LES PREMIERS !</h3>
					<p class="appear">
						Grâce &agrave; nos expérimentations et calculs avancés, <b>Mediaweb</b> est en mesure de faire en sorte que votre site ressorte en premier sur les <b>moteurs de recherche</b> (Google, Yahoo et Bing).
					</p>
				</div>
				<div class="col-xs-12">
					<img src="images/seo-sciencelayout.png" width="1124" height="834" class="chalk-picture appear" alt="referencement" title="referencement seo" />
				</div>
				<div class="col-xs-12">
						<a href="seo-referencement.html" class="section-button appear">
							<img src="images/button-arrow.png" width="50" height="25" class="" alt="SEO" title="search engine optimization"> EN SAVOIR PLUS
						</a>
					</div>
			</div>
			<img src="images/svg/curve.svg" style="width:100%;" class="svg curve olive" alt="Création site internet" title="Création site internet">
		</section>

		<!-- Section Social -->
		<section id="social" class="full-section">
			<div id="particles-js" class="parallax"></div>
			<div class="total-center" style="pointer-events: none;">
				<div class="container-fluid">
					<div class="col-xs-12">
						<h3 class="section-title appear">REJOIGNEZ VOTRE CLIENTÈLE</h3>
						<p class="appear">
							Votre site web est lancé! Vous souhaitez maximiser votre vitrine virtuelle &agrave; travers internet. <b>Mediaweb</b> est en mesure de vous guider, afin que votre image de marque et votre <b>présence sur le web</b> soient cohérentes au contenu de votre site.
						</p>
					</div>
					<div class="col-xs-12">
						<img src="images/social-bubbles.png" width="1125" height="691" class="bubbles-picture appear" alt="medias sociaux" title="médias sociaux" />
					</div>
					<div class="col-xs-12">

					</div>
				</div>
			</div>
			<img src="images/svg/curve.svg" style="width:100%;" class="svg curve purple" alt="facebook" title="google">
		</section>

		<!-- Section Realisations -->
		<section id="realisations" class="full-section full-section-mobile">
			<div class="background-realisation parallax skewRealBG" style="background-image:url('images/back-01-reals.jpg');"></div>
			<div class="total-center" style="height: 100%;">
				<div>

          
					<!-- START SLIDER HOLDER -->
					<div id="ss-holder" class="ss-holder">
						<div id="effects"><!-- script will add automatically the scroll effect class here -->
							<article id="articlehold">

                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.renovationevolution.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/conception_site-internet-evolution.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.renovationevolution.ca/" target="_blank" title="Voir le site web">
                            Évolution Construction                          </a>
                        </h3>
  							        <div class="content-text">
                          Conception du site internet  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="https://www.mtlmetro.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/conception_site-internet-peinture.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="https://www.mtlmetro.com/" target="_blank" title="Voir le site web">
                            Peinture Montréal Métro                          </a>
                        </h3>
  							        <div class="content-text">
                          Conception du site internet  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="https://www.servicessed.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/conception_site-internet-sed.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="https://www.servicessed.com/" target="_blank" title="Voir le site web">
                            Service SED                          </a>
                        </h3>
  							        <div class="content-text">
                          Conception site internet  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="https://www.entretienmenagerrivesud.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/creation_site_web_excel.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="https://www.entretienmenagerrivesud.ca/" target="_blank" title="Voir le site web">
                            Excel Maintenance                          </a>
                        </h3>
  							        <div class="content-text">
                          Conception du site internet et SEO  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="https://www.locube.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/creation_site_web_locube.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="https://www.locube.ca/" target="_blank" title="Voir le site web">
                            Loucube                          </a>
                        </h3>
  							        <div class="content-text">
                          Conception du site Internet  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="https://www.quebecdomotique.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/conception_site-internet-domotique.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="https://www.quebecdomotique.ca/" target="_blank" title="Voir le site web">
                            Québec Domotique                          </a>
                        </h3>
  							        <div class="content-text">
                          Conception du site internet et SEO  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="https://www.beldilighting.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/conception_site-internet-beldi.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="https://www.beldilighting.com/" target="_blank" title="Voir le site web">
                            Beldi Lighthing                          </a>
                        </h3>
  							        <div class="content-text">
                          Conception Site Internet et SEO  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="https://www.racicot-ass.qc.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/conception_site-internet-racicot.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="https://www.racicot-ass.qc.ca/" target="_blank" title="Voir le site web">
                            Évaluateurs Racicot et Associés                          </a>
                        </h3>
  							        <div class="content-text">
                          Conception site internet Racicot et Associés  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="https://www.bec-fin.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/conception_site-internet-bec-fin.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="https://www.bec-fin.ca/" target="_blank" title="Voir le site web">
                            Traiteur Bec Fin                          </a>
                        </h3>
  							        <div class="content-text">
                          Traiteur haut de gamme à Ville Lasalle  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="https://geoahall.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/site_internet_montreal_geoahall.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="https://geoahall.com/" target="_blank" title="Voir le site web">
                            Géo A. Hall                          </a>
                        </h3>
  							        <div class="content-text">
                          Entreprise de transport  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="conteneurscarlex.html" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/site_internet_varennes-carlex.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="conteneurscarlex.html" target="_blank" title="Voir le site web">
                            Conteneurs Carlex                          </a>
                        </h3>
  							        <div class="content-text">
                          Location de conteneurs  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://ronaldjolicoeur.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/ronaldjolicoeur.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://ronaldjolicoeur.com/" target="_blank" title="Voir le site web">
                            Ronald Jolicoeur                          </a>
                        </h3>
  							        <div class="content-text">
                          Courtier en transport depuis plus de 30 ans!  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://renovecmetropolitain.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/renovec.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://renovecmetropolitain.com/" target="_blank" title="Voir le site web">
                            Rénovec Métropolitain                          </a>
                        </h3>
  							        <div class="content-text">
                          Leader incontesté depuis plus de 25 ANS !   							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://demolitionomik.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/omik.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://demolitionomik.ca/" target="_blank" title="Voir le site web">
                            Les entreprises OMIK                          </a>
                        </h3>
  							        <div class="content-text">
                          Spécialiste de la démolition et plus!  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://frimabec.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/frimabec.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://frimabec.ca/" target="_blank" title="Voir le site web">
                            frimabec Inc.                          </a>
                        </h3>
  							        <div class="content-text">
                          Spécialistes en réfrigération commerciale  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://premiereslettres.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/ecole.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://premiereslettres.com/" target="_blank" title="Voir le site web">
                            École des Premières Lettres                          </a>
                        </h3>
  							        <div class="content-text">
                          L'école primaire privée du Plateau Mont-Royal!  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://armoirestremblay.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/armoirestremblay.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://armoirestremblay.com/" target="_blank" title="Voir le site web">
                            Armoires Tremblay                          </a>
                        </h3>
  							        <div class="content-text">
                          Entreprise familiale depuis 1984!  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://unifrontieres.coop/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/coop.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://unifrontieres.coop/" target="_blank" title="Voir le site web">
                            Coop Unifrontières                          </a>
                        </h3>
  							        <div class="content-text">
                          La force d'un réseau!

  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://cimentech.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/cimentech.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://cimentech.ca/" target="_blank" title="Voir le site web">
                            Cimentech                          </a>
                        </h3>
  							        <div class="content-text">
                          Spécialiste en réparation de béton & maçonnerie  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.groupecollette.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/collette.png" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.groupecollette.com/" target="_blank" title="Voir le site web">
                            Groupe Collette                          </a>
                        </h3>
  							        <div class="content-text">
                            							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://conteneur.co/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/cco.png" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://conteneur.co/" target="_blank" title="Voir le site web">
                            Conteneur.co                          </a>
                        </h3>
  							        <div class="content-text">
                            							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://cloturereno.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/reno.png" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://cloturereno.com/" target="_blank" title="Voir le site web">
                            Clôture Réno                          </a>
                        </h3>
  							        <div class="content-text">
                            							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://attisee.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/attisee.png" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://attisee.com/" target="_blank" title="Voir le site web">
                            L'Attisée                          </a>
                        </h3>
  							        <div class="content-text">
                            							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://portesetfenetresexcel.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/excel.png" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://portesetfenetresexcel.com/" target="_blank" title="Voir le site web">
                            Portes et fenêtres Excel                          </a>
                        </h3>
  							        <div class="content-text">
                            							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.transportexpert.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/transport-expert.png" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.transportexpert.com/" target="_blank" title="Voir le site web">
                            Assuraction Transport Expert inc.                          </a>
                        </h3>
  							        <div class="content-text">
                            							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.aclasalle.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/aclasalle.png" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.aclasalle.com/" target="_blank" title="Voir le site web">
                            Armoires et Comptoirs Lasalle                          </a>
                        </h3>
  							        <div class="content-text">
                          Client chez Mediaweb depuis de nombreuses années, cette entreprise de conception et de fabrication d'armoires et de comptoirs de cuisine a opté pour un site adaptatif au look raffiné.   							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.ilyamarketing.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/ilyamarketing.png" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.ilyamarketing.ca/" target="_blank" title="Voir le site web">
                            il y a marketing                          </a>
                        </h3>
  							        <div class="content-text">
                            							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://actionsmultiflammes.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/actionsmultiflammes.png" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://actionsmultiflammes.com/" target="_blank" title="Voir le site web">
                            Actions MultiFlammes                          </a>
                        </h3>
  							        <div class="content-text">
                          Fidèle client chez Mediaweb, le spécialiste des poêles et foyers Actions Multiflammes a refait son site au goût du jour, tout en le rendant responsive.  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.igalambert.net/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/igalambert.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.igalambert.net/" target="_blank" title="Voir le site web">
                            IGA Lambert                          </a>
                        </h3>
  							        <div class="content-text">
                          Un site simple afin de présenter les différents magasins qui forment la bannière de qualité qu'est Les Marchés Lambert  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.emballages-citadins.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/emballagecitadin.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.emballages-citadins.com/" target="_blank" title="Voir le site web">
                            Emballages Citadin                          </a>
                        </h3>
  							        <div class="content-text">
                          Cette entreprise cherchait comment présenter ses spécialités avec originalité, différemment de la compétition; Mission accomplie  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.elliotconstruction.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/elliotconstruction.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.elliotconstruction.ca/" target="_blank" title="Voir le site web">
                            Elliot Construction                          </a>
                        </h3>
  							        <div class="content-text">
                          Du design pour cette entreprise qui reste au sommet des décors et designs de son domaine  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.rs-plc.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/rsplc.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.rs-plc.ca/" target="_blank" title="Voir le site web">
                            RS-PLC inc.                          </a>
                        </h3>
  							        <div class="content-text">
                          Un look moderne et adapté au domaine technique de ce client à la fine pointe dans son domaine d'activité.  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.serrurerielongueuil.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/serrurerielongueuil.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.serrurerielongueuil.com/" target="_blank" title="Voir le site web">
                            Serrurerie Longueuil                          </a>
                        </h3>
  							        <div class="content-text">
                          Un site qui dit tout et permet aux visiteurs de contacter efficacement cette entreprise qui répond jour et nuit aux appels de service  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.coursevintage.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/coursevintage.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.coursevintage.com/" target="_blank" title="Voir le site web">
                            Course Vintage                          </a>
                        </h3>
  							        <div class="content-text">
                          Un look rétro pour une entreprise de course de mustangs rétro sur la piste de Sanair! Course Vintage et Mediaweb, quelle équipe  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.boulonsjmbergeron.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/jmbergeron.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.boulonsjmbergeron.com/" target="_blank" title="Voir le site web">
                            Distribution JM Bergeron                          </a>
                        </h3>
  							        <div class="content-text">
                          Un site sur mesure qui présente de façon très efficace ce domaine de distribution pancanadien  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.arpenteurmontreal.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/tessiercloutier.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.arpenteurmontreal.com/" target="_blank" title="Voir le site web">
                            Tessier & Cloutier                          </a>
                        </h3>
  							        <div class="content-text">
                          Un site adapté et orienté pour le domaine de l'arpentage avec un design pleine page qui fait tout comprendre en un coup d'oeil  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.isolationgrenier.com/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/isolationgrenier.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.isolationgrenier.com/" target="_blank" title="Voir le site web">
                            Isolation Grenier                          </a>
                        </h3>
  							        <div class="content-text">
                          Un site à la hauteur pour une entreprise en pleine expansion dans le domaine de l'isolation résidentielle.  Cette entreprise n'a plus rien à envier à la compétition  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.toituresbl.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/toiturebl.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.toituresbl.ca/" target="_blank" title="Voir le site web">
                            Toitures Boisvert & Lafrance                          </a>
                        </h3>
  							        <div class="content-text">
                          Un site web résolument moderne qui permet de se démarquer dans un domaine très prisé sur le web, voilà ce que Mediaweb a offert à ce couvreur professionnel   							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                  								<!-- START SLIDE -->
  								<section>
  								  <div class="ss-row go-anim">
  								    <!-- START IMAGE HOLDER -->
  								    <div class="hover-effect h-style">
                        <a href="http://www.iservicecenter.ca/" target="_blank" title="Voir le site web">
                          <img src="mediatask/dump/iservicecenter.jpg" width="800" height="600" class="clean-img">
                          <div class="mask">
                            <i class="fa fa-search icon-search"></i><span class="img-rollover"></span>
                          </div>
                        </a>
  								    </div>
  								    <!-- END IMAGE HOLDER -->
  								    <!-- START CONTENT HOLDER -->
  								    <div class="ss-container">
  							        <h3 class="content-title">
                          <a href="http://www.iservicecenter.ca/" target="_blank" title="Voir le site web">
                            i Service Center                          </a>
                        </h3>
  							        <div class="content-text">
                          Un site adapté au domaine de l'entretien d'hélicoptères de grandes marques telles que Bell Helicopter, Robinson Helicopter et beaucoup d'autres!  							        </div>
  							        <!-- END INFO HOLDER -->
  								    </div>
  								    <!-- END CONTENT HOLDER -->
  								  </div>
  								</section>
  								<!-- END SLIDE -->
                
							</article>
							<!-- START NAVIGATION ARROWS -->
							<div class="ss-nav-arrows-next">
								<i id="next-arrow" class="fa fa-angle-right"></i>
							</div>
							<div class="ss-nav-arrows-prev" style="">
								<i id="prev-arrow" class="fa fa-angle-left"></i>
							</div>
							<!-- END NAVIGATION ARROWS -->
						</div>
					</div>
					<!-- END SLIDER HOLDER -->

				</div>
			</div>
		</section>

		
<!-- SCRIPTS -->

<script type="text/javascript">
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','../www.google-analytics.com/analytics.js','ga');
	ga('create', 'UA-2675528-19', 'auto');
	ga('send', 'pageview');
</script><script src="js/index/builds/javascripts.min.js"></script>


    <!------------------------------------------------------------------------->
	</body>

<!-- Mirrored from www.mediaweb.ca/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 20 Mar 2019 15:18:04 GMT -->
</html>


